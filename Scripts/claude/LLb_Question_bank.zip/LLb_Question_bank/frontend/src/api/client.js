/**
 * API Client for LLB Question Bank
 * Handles all HTTP requests to the backend API
 * 
 * Usage:
 * import { questionsAPI, studyAPI, progressAPI } from './api/client'
 * 
 * const questions = await questionsAPI.getAll()
 * const study = await studyAPI.getAll(questionId)
 */

import axios from 'axios';

// Get API URL from environment or use default
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

console.log('🔌 API URL:', API_URL);
console.log('📦 Environment:', process.env.REACT_APP_ENV);

// ============================================================================
// CREATE AXIOS INSTANCE
// ============================================================================

export const apiClient = axios.create({
  baseURL: API_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor
apiClient.interceptors.request.use(
  (config) => {
    // Add auth token if available
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Add response interceptor
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Handle unauthorized
      localStorage.removeItem('auth_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// ============================================================================
// QUESTIONS API
// ============================================================================

export const questionsAPI = {
  /**
   * Get all questions with pagination and filters
   * @param {number} skip - Number of questions to skip
   * @param {number} limit - Number of questions to return
   * @param {string} subject - Filter by subject
   * @param {number} year - Filter by year
   * @returns {Promise} Array of questions
   */
  getAll: async (skip = 0, limit = 20, subject = null, year = null) => {
    try {
      const params = { skip, limit };
      if (subject) params.subject = subject;
      if (year) params.year = year;
      
      const response = await apiClient.get('/api/questions/', { params });
      return response.data;
    } catch (error) {
      console.error('Error fetching questions:', error);
      throw error;
    }
  },

  /**
   * Get single question by ID
   * @param {string} id - Question ID
   * @returns {Promise} Question object
   */
  getById: async (id) => {
    try {
      const response = await apiClient.get(`/api/questions/${id}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching question ${id}:`, error);
      throw error;
    }
  },

  /**
   * Search questions
   * @param {string} query - Search query
   * @param {number} skip - Skip results
   * @param {number} limit - Limit results
   * @returns {Promise} Search results
   */
  search: async (query, skip = 0, limit = 20) => {
    try {
      const response = await apiClient.post('/api/questions/search', {
        query,
        skip,
        limit,
      });
      return response.data;
    } catch (error) {
      console.error('Error searching questions:', error);
      throw error;
    }
  },

  /**
   * Get all available subjects
   * @returns {Promise} List of subjects
   */
  getSubjects: async () => {
    try {
      const response = await apiClient.get('/api/questions/subjects/list');
      return response.data.subjects;
    } catch (error) {
      console.error('Error fetching subjects:', error);
      throw error;
    }
  },

  /**
   * Get all available years
   * @returns {Promise} List of years
   */
  getYears: async () => {
    try {
      const response = await apiClient.get('/api/questions/years/list');
      return response.data.years;
    } catch (error) {
      console.error('Error fetching years:', error);
      throw error;
    }
  },

  /**
   * Get all available question types
   * @returns {Promise} List of types
   */
  getTypes: async () => {
    try {
      const response = await apiClient.get('/api/questions/types/list');
      return response.data.types;
    } catch (error) {
      console.error('Error fetching types:', error);
      throw error;
    }
  },

  /**
   * Get duplicate questions
   * @returns {Promise} List of duplicate questions
   */
  getDuplicates: async () => {
    try {
      const response = await apiClient.get('/api/questions/duplicates/list');
      return response.data.duplicates;
    } catch (error) {
      console.error('Error fetching duplicates:', error);
      throw error;
    }
  },

  /**
   * Get questions statistics
   * @returns {Promise} Statistics object
   */
  getStats: async () => {
    try {
      const response = await apiClient.get('/api/questions/stats/overview');
      return response.data;
    } catch (error) {
      console.error('Error fetching statistics:', error);
      throw error;
    }
  },
};

// ============================================================================
// STUDY MATERIALS API
// ============================================================================

export const studyAPI = {
  /**
   * Get all study materials for a question
   * @param {string} questionId - Question ID
   * @returns {Promise} Complete study material object
   */
  getAll: async (questionId) => {
    try {
      const response = await apiClient.get(`/api/study/${questionId}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching study materials for ${questionId}:`, error);
      throw error;
    }
  },

  /**
   * Get long answer (20 marks)
   * @param {string} questionId - Question ID
   * @returns {Promise} Long answer content
   */
  getLongAnswer: async (questionId) => {
    try {
      const response = await apiClient.get(`/api/study/${questionId}/long-answer`);
      return response.data.answer;
    } catch (error) {
      console.error(`Error fetching long answer:`, error);
      throw error;
    }
  },

  /**
   * Get short answer (8 marks)
   * @param {string} questionId - Question ID
   * @returns {Promise} Short answer content
   */
  getShortAnswer: async (questionId) => {
    try {
      const response = await apiClient.get(`/api/study/${questionId}/short-answer`);
      return response.data.answer;
    } catch (error) {
      console.error(`Error fetching short answer:`, error);
      throw error;
    }
  },

  /**
   * Get key points
   * @param {string} questionId - Question ID
   * @returns {Promise} Array of key points
   */
  getKeyPoints: async (questionId) => {
    try {
      const response = await apiClient.get(`/api/study/${questionId}/key-points`);
      return response.data.key_points;
    } catch (error) {
      console.error(`Error fetching key points:`, error);
      throw error;
    }
  },

  /**
   * Get case laws
   * @param {string} questionId - Question ID
   * @returns {Promise} Array of case laws
   */
  getCaseLaws: async (questionId) => {
    try {
      const response = await apiClient.get(`/api/study/${questionId}/case-laws`);
      return response.data.case_laws;
    } catch (error) {
      console.error(`Error fetching case laws:`, error);
      throw error;
    }
  },

  /**
   * Get bare acts and statutes
   * @param {string} questionId - Question ID
   * @returns {Promise} Array of bare acts
   */
  getBareActs: async (questionId) => {
    try {
      const response = await apiClient.get(`/api/study/${questionId}/bare-acts`);
      return response.data.bare_acts;
    } catch (error) {
      console.error(`Error fetching bare acts:`, error);
      throw error;
    }
  },

  /**
   * Get MCQ questions
   * @param {string} questionId - Question ID
   * @returns {Promise} Array of MCQ questions
   */
  getMCQ: async (questionId) => {
    try {
      const response = await apiClient.get(`/api/study/${questionId}/mcq`);
      return response.data.mcq_questions;
    } catch (error) {
      console.error(`Error fetching MCQ:`, error);
      throw error;
    }
  },

  /**
   * Get flashcard
   * @param {string} questionId - Question ID
   * @returns {Promise} Flashcard object
   */
  getFlashcard: async (questionId) => {
    try {
      const response = await apiClient.get(`/api/study/${questionId}/flashcard`);
      return response.data.flashcard;
    } catch (error) {
      console.error(`Error fetching flashcard:`, error);
      throw error;
    }
  },

  /**
   * Get revision notes
   * @param {string} questionId - Question ID
   * @returns {Promise} Revision notes content
   */
  getRevisionNotes: async (questionId) => {
    try {
      const response = await apiClient.get(`/api/study/${questionId}/revision-notes`);
      return response.data.revision_notes;
    } catch (error) {
      console.error(`Error fetching revision notes:`, error);
      throw error;
    }
  },
};

// ============================================================================
// FLASHCARDS API
// ============================================================================

export const flashcardsAPI = {
  /**
   * Get flashcards due for review
   * @param {string} studentId - Student ID
   * @param {number} limit - Max cards to return
   * @returns {Promise} Array of due flashcards
   */
  getDue: async (studentId, limit = 10) => {
    try {
      const response = await apiClient.get(`/api/flashcards/due/${studentId}`, {
        params: { limit },
      });
      return response.data.flashcards;
    } catch (error) {
      console.error('Error fetching due flashcards:', error);
      throw error;
    }
  },

  /**
   * Record flashcard review (SM-2 algorithm)
   * @param {string} flashcardId - Flashcard ID
   * @param {object} data - Review data (is_correct, time_taken_seconds, difficulty)
   * @returns {Promise} Updated flashcard data
   */
  recordReview: async (flashcardId, data) => {
    try {
      const response = await apiClient.post(
        `/api/flashcards/${flashcardId}/review`,
        data
      );
      return response.data;
    } catch (error) {
      console.error('Error recording flashcard review:', error);
      throw error;
    }
  },

  /**
   * Get flashcard statistics
   * @param {string} studentId - Student ID
   * @returns {Promise} Statistics object
   */
  getStats: async (studentId) => {
    try {
      const response = await apiClient.get(`/api/flashcards/stats/${studentId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching flashcard stats:', error);
      throw error;
    }
  },

  /**
   * Create flashcard from question
   * @param {string} questionId - Question ID
   * @param {string} studentId - Student ID
   * @param {string} deckId - Deck ID
   * @returns {Promise} Created flashcard
   */
  create: async (questionId, studentId, deckId) => {
    try {
      const response = await apiClient.post(
        `/api/flashcards/create/${questionId}`,
        {},
        { params: { student_id: studentId, deck_id: deckId } }
      );
      return response.data;
    } catch (error) {
      console.error('Error creating flashcard:', error);
      throw error;
    }
  },

  /**
   * Delete flashcard
   * @param {string} flashcardId - Flashcard ID
   * @param {string} studentId - Student ID
   * @returns {Promise} Deletion confirmation
   */
  delete: async (flashcardId, studentId) => {
    try {
      const response = await apiClient.delete(
        `/api/flashcards/${flashcardId}`,
        { params: { student_id: studentId } }
      );
      return response.data;
    } catch (error) {
      console.error('Error deleting flashcard:', error);
      throw error;
    }
  },
};

// ============================================================================
// PROGRESS API
// ============================================================================

export const progressAPI = {
  /**
   * Get student dashboard
   * @param {string} studentId - Student ID
   * @returns {Promise} Dashboard statistics
   */
  getDashboard: async (studentId) => {
    try {
      const response = await apiClient.get(`/api/progress/dashboard/${studentId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching dashboard:', error);
      throw error;
    }
  },

  /**
   * Get progress by subject
   * @param {string} studentId - Student ID
   * @param {string} subject - Subject name
   * @returns {Promise} Subject progress data
   */
  getBySubject: async (studentId, subject) => {
    try {
      const response = await apiClient.get(
        `/api/progress/subject/${studentId}/${subject}`
      );
      return response.data;
    } catch (error) {
      console.error('Error fetching subject progress:', error);
      throw error;
    }
  },

  /**
   * Get single question progress
   * @param {string} studentId - Student ID
   * @param {string} questionId - Question ID
   * @returns {Promise} Question progress data
   */
  getQuestion: async (studentId, questionId) => {
    try {
      const response = await apiClient.get(
        `/api/progress/${studentId}/${questionId}`
      );
      return response.data;
    } catch (error) {
      console.error('Error fetching question progress:', error);
      throw error;
    }
  },

  /**
   * Update question progress
   * @param {string} studentId - Student ID
   * @param {string} questionId - Question ID
   * @param {object} data - Progress data to update
   * @returns {Promise} Updated progress
   */
  updateQuestion: async (studentId, questionId, data) => {
    try {
      const response = await apiClient.put(
        `/api/progress/${studentId}/${questionId}`,
        data
      );
      return response.data;
    } catch (error) {
      console.error('Error updating progress:', error);
      throw error;
    }
  },

  /**
   * Get weak areas
   * @param {string} studentId - Student ID
   * @returns {Promise} Array of weak areas
   */
  getWeakAreas: async (studentId) => {
    try {
      const response = await apiClient.get(
        `/api/progress/weak-areas/${studentId}`
      );
      return response.data.weak_areas;
    } catch (error) {
      console.error('Error fetching weak areas:', error);
      throw error;
    }
  },

  /**
   * Get study streak
   * @param {string} studentId - Student ID
   * @returns {Promise} Streak data
   */
  getStreak: async (studentId) => {
    try {
      const response = await apiClient.get(
        `/api/progress/streak/${studentId}`
      );
      return response.data;
    } catch (error) {
      console.error('Error fetching streak:', error);
      throw error;
    }
  },

  /**
   * Reset all progress
   * @param {string} studentId - Student ID
   * @returns {Promise} Reset confirmation
   */
  reset: async (studentId) => {
    try {
      const response = await apiClient.post(
        `/api/progress/reset/${studentId}`
      );
      return response.data;
    } catch (error) {
      console.error('Error resetting progress:', error);
      throw error;
    }
  },
};

// ============================================================================
// SYSTEM API
// ============================================================================

export const systemAPI = {
  /**
   * Get API health status
   * @returns {Promise} Health status
   */
  getHealth: async () => {
    try {
      const response = await apiClient.get('/health');
      return response.data;
    } catch (error) {
      console.error('Error checking health:', error);
      throw error;
    }
  },

  /**
   * Get system statistics
   * @returns {Promise} System stats
   */
  getStats: async () => {
    try {
      const response = await apiClient.get('/stats');
      return response.data;
    } catch (error) {
      console.error('Error fetching stats:', error);
      throw error;
    }
  },
};

export default apiClient;
