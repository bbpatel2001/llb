import { BasePlugin } from './PluginInterface';
/**
 * Mock Test Plugin - Creates and manages mock tests for exam preparation
 * Generates tests from question bank, evaluates answers, and provides feedback
 */
export declare class MockTestPlugin extends BasePlugin {
    private mockTests;
    private testResults;
    constructor();
    initialize(): Promise<void>;
    /**
     * Execute custom actions
     */
    execute(action: string, data: any): Promise<any>;
    /**
     * Create a mock test
     */
    private createMockTest;
    /**
     * Generate test questions
     */
    private generateTestQuestions;
    /**
     * Generate test instructions
     */
    private generateTestInstructions;
    /**
     * Get mock test
     */
    private getMockTest;
    /**
     * Submit mock test answers
     */
    private submitMockTest;
    /**
     * Evaluate answers
     */
    private evaluateAnswers;
    /**
     * Calculate grade
     */
    private calculateGrade;
    /**
     * Generate feedback
     */
    private generateFeedback;
    /**
     * Get test results for user
     */
    private getTestResults;
    /**
     * Generate performance report
     */
    private generatePerformanceReport;
    /**
     * Identify strong areas
     */
    private identifyStrongAreas;
    /**
     * Identify weak areas
     */
    private identifyWeakAreas;
    /**
     * Calculate performance trend
     */
    private calculateTrend;
    /**
     * Generate recommendations
     */
    private generateRecommendations;
    /**
     * Get test analytics
     */
    private getTestAnalytics;
}
export default MockTestPlugin;
//# sourceMappingURL=MockTestPlugin.d.ts.map