import { BasePlugin } from './PluginInterface';
/**
 * Analytics Plugin - Tracks user interactions and platform metrics
 */
export declare class AnalyticsPlugin extends BasePlugin {
    private events;
    private eventMetrics;
    constructor();
    initialize(): Promise<void>;
    /**
     * Track answer generation
     */
    private trackAnswerGeneration;
    /**
     * Track flashcard creation
     */
    private trackFlashcardCreation;
    /**
     * Track timeline generation
     */
    private trackTimelineGeneration;
    /**
     * Track an event
     */
    private trackEvent;
    /**
     * Execute custom actions
     */
    execute(action: string, data: any): Promise<any>;
    /**
     * Get all metrics
     */
    private getMetrics;
    /**
     * Get events by type
     */
    private getEventsByType;
    /**
     * Generate analytics report
     */
    private generateReport;
    /**
     * Get top activities
     */
    private getTopActivities;
    /**
     * Generate recommendations based on analytics
     */
    private generateRecommendations;
    /**
     * Get top content
     */
    private getTopContent;
}
export default AnalyticsPlugin;
//# sourceMappingURL=AnalyticsPlugin.d.ts.map