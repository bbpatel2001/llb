import { IPlugin, PluginHooks } from './PluginInterface';
/**
 * Plugin Manager - Manages plugin lifecycle and execution
 */
export declare class PluginManager {
    private static instance;
    private plugins;
    private hooks;
    private constructor();
    /**
     * Get singleton instance
     */
    static getInstance(): PluginManager;
    /**
     * Register a plugin
     */
    register(plugin: IPlugin): Promise<void>;
    /**
     * Unregister a plugin
     */
    unregister(name: string): Promise<void>;
    /**
     * Get a plugin
     */
    getPlugin(name: string): IPlugin | undefined;
    /**
     * Get all plugins
     */
    getAllPlugins(): IPlugin[];
    /**
     * Get enabled plugins
     */
    getEnabledPlugins(): IPlugin[];
    /**
     * Enable a plugin
     */
    enablePlugin(name: string): Promise<void>;
    /**
     * Disable a plugin
     */
    disablePlugin(name: string): Promise<void>;
    /**
     * Register hooks from a plugin
     */
    private registerHooks;
    /**
     * Remove hooks from a plugin
     */
    private removeHooks;
    /**
     * Execute a hook
     */
    executeHook(hookName: keyof PluginHooks, data: any): Promise<any>;
    /**
     * Execute plugin action
     */
    executePluginAction(pluginName: string, action: string, data: any): Promise<any>;
    /**
     * Get plugin statistics
     */
    getStats(): any;
}
declare const _default: PluginManager;
export default _default;
//# sourceMappingURL=PluginManager.d.ts.map