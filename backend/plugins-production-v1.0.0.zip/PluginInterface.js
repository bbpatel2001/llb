/**
 * Plugin Interface for LLB Platform
 * All plugins must implement this interface
 */
/**
 * Abstract base class for plugins
 */
export class BasePlugin {
    constructor(config) {
        this.config = {
            ...config,
            enabled: config.enabled || false,
        };
    }
    async initialize() {
        console.log(`[Plugin] Initializing ${this.config.name} v${this.config.version}`);
    }
    async activate() {
        this.config.enabled = true;
        console.log(`[Plugin] Activated ${this.config.name}`);
    }
    async deactivate() {
        this.config.enabled = false;
        console.log(`[Plugin] Deactivated ${this.config.name}`);
    }
    getMetadata() {
        return this.config;
    }
}
//# sourceMappingURL=PluginInterface.js.map