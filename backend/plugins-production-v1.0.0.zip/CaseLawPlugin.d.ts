import { BasePlugin } from './PluginInterface';
/**
 * Case Law Plugin - Manages and enriches case law content
 * Links cases to answers, extracts legal principles, and provides case analysis
 */
export declare class CaseLawPlugin extends BasePlugin {
    constructor();
    initialize(): Promise<void>;
    /**
     * Enrich answer with relevant case law
     */
    private enrichAnswerWithCases;
    /**
     * Validate case law before creation
     */
    private validateCaseLaw;
    /**
     * Find cases related to answer content
     */
    private findRelatedCases;
    /**
     * Extract case keywords from content
     */
    private extractCaseKeywords;
    /**
     * Calculate relevance score (0-1)
     */
    private calculateRelevance;
    /**
     * Execute custom actions
     */
    execute(action: string, data: any): Promise<any>;
    /**
     * Search cases
     */
    private searchCases;
    /**
     * Get detailed case analysis
     */
    private getCaseAnalysis;
    /**
     * Get landmark cases for a subject
     */
    private getLandmarkCases;
    /**
     * Generate case law timeline
     */
    private generateCaseTimeline;
}
export default CaseLawPlugin;
//# sourceMappingURL=CaseLawPlugin.d.ts.map