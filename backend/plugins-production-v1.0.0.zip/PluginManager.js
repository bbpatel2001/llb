/**
 * Plugin Manager - Manages plugin lifecycle and execution
 */
export class PluginManager {
    constructor() {
        this.plugins = new Map();
        this.hooks = new Map();
    }
    /**
     * Get singleton instance
     */
    static getInstance() {
        if (!PluginManager.instance) {
            PluginManager.instance = new PluginManager();
        }
        return PluginManager.instance;
    }
    /**
     * Register a plugin
     */
    async register(plugin) {
        const name = plugin.config.name;
        if (this.plugins.has(name)) {
            throw new Error(`Plugin "${name}" is already registered`);
        }
        await plugin.initialize();
        this.plugins.set(name, plugin);
        // Register hooks if plugin defines them
        if (plugin.hooks) {
            this.registerHooks(name, plugin.hooks);
        }
        console.log(`[PluginManager] Registered plugin: ${name} v${plugin.config.version}`);
    }
    /**
     * Unregister a plugin
     */
    async unregister(name) {
        const plugin = this.plugins.get(name);
        if (!plugin) {
            throw new Error(`Plugin "${name}" not found`);
        }
        await plugin.deactivate();
        this.plugins.delete(name);
        // Remove hooks
        this.removeHooks(name);
        console.log(`[PluginManager] Unregistered plugin: ${name}`);
    }
    /**
     * Get a plugin
     */
    getPlugin(name) {
        return this.plugins.get(name);
    }
    /**
     * Get all plugins
     */
    getAllPlugins() {
        return Array.from(this.plugins.values());
    }
    /**
     * Get enabled plugins
     */
    getEnabledPlugins() {
        return this.getAllPlugins().filter((p) => p.config.enabled);
    }
    /**
     * Enable a plugin
     */
    async enablePlugin(name) {
        const plugin = this.plugins.get(name);
        if (!plugin) {
            throw new Error(`Plugin "${name}" not found`);
        }
        await plugin.activate();
        console.log(`[PluginManager] Enabled plugin: ${name}`);
    }
    /**
     * Disable a plugin
     */
    async disablePlugin(name) {
        const plugin = this.plugins.get(name);
        if (!plugin) {
            throw new Error(`Plugin "${name}" not found`);
        }
        await plugin.deactivate();
        console.log(`[PluginManager] Disabled plugin: ${name}`);
    }
    /**
     * Register hooks from a plugin
     */
    registerHooks(pluginName, hooks) {
        Object.entries(hooks).forEach(([hookName, hookFn]) => {
            const key = hookName;
            if (!this.hooks.has(key)) {
                this.hooks.set(key, []);
            }
            const hookList = this.hooks.get(key);
            hookList.push(hookFn.bind(hooks));
            console.log(`[PluginManager] Registered hook: ${pluginName}.${hookName}`);
        });
    }
    /**
     * Remove hooks from a plugin
     */
    removeHooks(pluginName) {
        this.hooks.forEach((hookList, hookName) => {
            const index = hookList.findIndex((h) => h.name.includes(pluginName));
            if (index > -1) {
                hookList.splice(index, 1);
                console.log(`[PluginManager] Removed hook: ${pluginName}.${hookName}`);
            }
        });
    }
    /**
     * Execute a hook
     */
    async executeHook(hookName, data) {
        const hookList = this.hooks.get(hookName) || [];
        let result = data;
        for (const hook of hookList) {
            try {
                result = await hook(result);
            }
            catch (error) {
                console.error(`[PluginManager] Error executing hook ${hookName}:`, error);
            }
        }
        return result;
    }
    /**
     * Execute plugin action
     */
    async executePluginAction(pluginName, action, data) {
        const plugin = this.plugins.get(pluginName);
        if (!plugin) {
            throw new Error(`Plugin "${pluginName}" not found`);
        }
        if (!plugin.config.enabled) {
            throw new Error(`Plugin "${pluginName}" is disabled`);
        }
        return plugin.execute(action, data);
    }
    /**
     * Get plugin statistics
     */
    getStats() {
        return {
            total: this.plugins.size,
            enabled: this.getEnabledPlugins().length,
            plugins: Array.from(this.plugins.values()).map((p) => ({
                name: p.config.name,
                version: p.config.version,
                enabled: p.config.enabled,
                description: p.config.description,
            })),
        };
    }
}
export default PluginManager.getInstance();
//# sourceMappingURL=PluginManager.js.map